ls -l
